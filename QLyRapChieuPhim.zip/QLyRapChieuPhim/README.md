# HSK_QLyRapPhim
https://docs.google.com/document/d/1Mc0FzQLa7FE8rZtsp-PCDaxTQDQvdNgHfc6pMSinUZQ/edit?usp=sharing
