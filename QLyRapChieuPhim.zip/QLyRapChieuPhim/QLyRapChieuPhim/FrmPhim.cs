﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLyRapChieuPhim
{
    public partial class FrmPhim : Form
    {
        public FrmPhim()
        {
            InitializeComponent();
        }

        SqlConnection conn;

        private void FrmPhim_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QLRP"].ConnectionString.ToString();
            conn = new SqlConnection(conString);
            conn.Open();
            dgvPhim.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            GetAll();
        }

        private void FrmPhim_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        public void GetAll()
        {
            string sqlSelect = "select * from view_phim";
            SqlCommand cmd = new SqlCommand(sqlSelect, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvPhim.DataSource = dt;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dgvPhim_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dgvPhim.CurrentRow.Index;
            tbMaPhim.Text = dgvPhim.Rows[i].Cells[0].Value.ToString();
            tbTenPhim.Text = dgvPhim.Rows[i].Cells[1].Value.ToString();
            tbNuoc.Text = dgvPhim.Rows[i].Cells[2].Value.ToString();
            tbHang.Text = dgvPhim.Rows[i].Cells[3].Value.ToString();
            tbDaoDien.Text = dgvPhim.Rows[i].Cells[4].Value.ToString();
            tbTheLoai.Text = dgvPhim.Rows[i].Cells[5].Value.ToString();
            dtStart.Text = dgvPhim.Rows[i].Cells[6].Value.ToString();
            dtEnd.Text = dgvPhim.Rows[i].Cells[7].Value.ToString();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            tbMaPhim.Text = "";
            tbTenPhim.Text = "";
            tbNuoc.Text = "";
            tbHang.Text = "";
            tbDaoDien.Text = "";
            tbTheLoai.Text = "";

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string sqlInsert = "insert into tblPhim values(@sMaPhim,@sTenPhim,@sMaNuocSX,@sMaHangSX," +
                "@sDaoDien,@sMaTheLoai,@dNgayKhoiChieu,@dNgayKetThuc)";
            SqlCommand cmd = new SqlCommand(sqlInsert, conn);
            cmd.Parameters.AddWithValue("sMaPhim", tbMaPhim.Text);
            cmd.Parameters.AddWithValue("sTenPhim", tbTenPhim.Text);
            cmd.Parameters.AddWithValue("sMaNuocSX", tbNuoc.Text);
            cmd.Parameters.AddWithValue("sMaHangSX", tbHang.Text);
            cmd.Parameters.AddWithValue("sDaoDien", tbDaoDien.Text);
            cmd.Parameters.AddWithValue("sMaTheLoai", tbTheLoai.Text);
            cmd.Parameters.AddWithValue("dNgayKhoiChieu", dtStart.Text);
            cmd.Parameters.AddWithValue("dNgayKetThuc", dtEnd.Text);

            cmd.ExecuteNonQuery();
            GetAll();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string sqlUpdate = "update tblPhim set sMaTheLoai=@sMaTheLoai,sTenPhim=@sTenPhim,sMaNuocSX=@sMaNuocSX, sMaHangSX=@sMaHangSX ,sDaoDien=@sDaoDien,dNgayKetThuc=@dNgayKetThuc,dNgayKhoiChieu=@dNgayKhoiChieu where sMaPhim=@sMaPhim";
            SqlCommand cmd = new SqlCommand(sqlUpdate, conn);
            cmd.Parameters.AddWithValue("sMaPhim", tbMaPhim.Text);
            cmd.Parameters.AddWithValue("sTenPhim", tbTenPhim.Text);
            cmd.Parameters.AddWithValue("sMaNuocSX", tbNuoc.Text);
            cmd.Parameters.AddWithValue("sMaHangSX", tbHang.Text);
            cmd.Parameters.AddWithValue("sDaoDien", tbDaoDien.Text);
            cmd.Parameters.AddWithValue("sMaTheLoai", tbTheLoai.Text);
            cmd.Parameters.AddWithValue("dNgayKhoiChieu", dtStart.Text);
            cmd.Parameters.AddWithValue("dNgayKetThuc", dtEnd.Text);

            cmd.ExecuteNonQuery();
            GetAll();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string sqlDelete = "delete from tblPhim  where sMaPhim=@sMaPhim";
            SqlCommand cmd = new SqlCommand(sqlDelete, conn);
            cmd.Parameters.AddWithValue("sMaPhim", tbMaPhim.Text);
            cmd.Parameters.AddWithValue("sTenPhim", tbTenPhim.Text);
            cmd.Parameters.AddWithValue("sMaNuocSX", tbNuoc.Text);
            cmd.Parameters.AddWithValue("sMaHangSX", tbHang.Text);
            cmd.Parameters.AddWithValue("sDaoDien", tbDaoDien.Text);
            cmd.Parameters.AddWithValue("sMaTheLoai", tbTheLoai.Text);
            cmd.Parameters.AddWithValue("dNgayKhoiChieu", dtStart.Text);
            cmd.Parameters.AddWithValue("dNgayKetThuc", dtEnd.Text);

            cmd.ExecuteNonQuery();
            GetAll();

        }

    }
}
