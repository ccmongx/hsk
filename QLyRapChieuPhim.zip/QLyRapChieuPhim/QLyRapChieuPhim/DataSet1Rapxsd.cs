﻿namespace QLyRapChieuPhim
{
}

namespace QLyRapChieuPhim
{


    public partial class DataSet1Rapxsd
    {
    }
}
namespace QLyRapChieuPhim {
    
    
    public partial class DataSet1Rapxsd {
    }
}
